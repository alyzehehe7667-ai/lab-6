# Lab 03: Transforming Textual and Image Data into Machine-Understandable Format

Contains `lab03/text_features.ipynb`, `lab03/image_features.ipynb`, `lab03/Lab_03_Text_and_Image_Features.ipynb`, `lab03/image_utils.py`, `lab03/dataset.npz`, and `lab03/report.md`.
